export interface Comment {
  id?: string; // Optional because it will be assigned by Firebase after adding
  content: string;
  username: string;
  date: Date;
  upvotedby: string[];
  downvotedby: string[]; 
  hasChild: boolean;
  parentCommentId: string | null;
  score: number;
  commentPath: string;
//   subComments?: Comment[]; // Optional field for nested comments
}
