import { Component, OnInit, Input } from '@angular/core';
import { collection, addDoc, getDocs } from "firebase/firestore";
import { Inject } from '@angular/core';
import { Firestore } from '@angular/fire/firestore';
import { doc, setDoc, updateDoc, getDoc } from '@angular/fire/firestore';
import { query, where } from '@angular/fire/firestore';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';
import { from, map, of } from 'rxjs';
import { Comment } from './comment';
@Component({
  selector: 'app-doc',
  standalone: true,
  imports: [CommonModule],
  // template: `
  //   <button type="submit" (click)="addComment('/posts/xip6QZ4V05vHW3RTzCrg/comments/HybxfSuhaKQTlFjizbaB/comments/9tw0S00jgCK4M8H67ezt/comments/G9txOpxf2UDmxgDljRoP', 'lvl4', 'lvl4' )">
  //     Add Comment
  //   </button>
  // `,
  styleUrls: ['./doc.component.css'],
  templateUrl: './doc.component.html',

})
export class DocComponent implements OnInit {
  constructor(@Inject(Firestore) private firestore: Firestore) { }
  L = false;
  comments?: Comment[]; // Use the Comment[] type here
  commentPaths: string[] = []; // Store all comment paths
  @Input() commentsInput: string = '/posts/xip6QZ4V05vHW3RTzCrg';
/////////////////////////////////////////////////////////////////////////////////////////////////

  ngOnInit(): void {
    if (this.commentsInput) {
      this.GetComments(this.commentsInput).then(() => {
        if (this.comments) {
          for (const comment of this.comments) {
            if (comment.commentPath) {
              this.commentPaths.push(comment.commentPath);
            }
          }
        }
        console.log(this.commentPaths); // Logs all parent comment paths
      });
    }
  }

  
  async addPost() {//this code can create a post and leave a place holder for comments
    const db = this.firestore;

    try {
      const docRef = await addDoc(collection(db, "posts"), {
        post_content: "Ada wong is the best",
        poster_id: "USer_1",
        date: 1815,
        score:0,
      });
      console.log("Document written with ID: ", docRef.id);
            // Create an empty 'comments' sub-collection by adding a placeholder document
    const commentsRef = doc(db, `posts/${docRef.id}/comments/placeholder`);
    await setDoc(commentsRef, { placeholder: true });
    console.log("Empty comments collection created for post ID:", docRef.id);

    } catch (e) {
      console.error("Error adding document: ", e);
    }
  }

  async GetComments(comPath: string) {
    const db = this.firestore;
    try {
      const commentsCollection = collection(db, comPath + '/comments');
      const commentsSnapshot = await getDocs(commentsCollection);
      const comments = commentsSnapshot.docs.map(doc => ({ 
        id: doc.id, 
        ...doc.data(), 
        content: doc.data()['content'],
        username: doc.data()['username'],
        date: doc.data()['date'],
        upvotedby: doc.data()['upvotedby'],
        downvotedby: doc.data()['downvotedby'],
        hasChild: doc.data()['hasChild'],
        parentCommentId: doc.data()['parentCommentId'],
        score: doc.data()['score'],
        commentPath: doc.data()['commentPath']        
      } as Comment));
      this.comments = comments;
      return comments; // Return the array of comments
    } catch (e) {
      console.error("Error fetching comments: ", e);
    }
    return;
  }

  
  async addComment(PATH: string, content: string, username: string) {
    const db = this.firestore;
    const PoC = this.isPostPathOrCommentPath(PATH);
    try {
      const postDocRef = doc(db, PATH);
      const postDocSnapshot = await getDoc(postDocRef);
      if (!postDocSnapshot.exists()) {
        console.error(`Post with ID ${PATH} does not exist!`);
        return;
      }
      console.log(`Post with ID ${PATH} exists!`);

      const newComment: Comment = {
        content: content,
        username: username,
        date: new Date(),
        upvotedby: ["yassin", "radi"], 
        downvotedby: ["sam", "james", "someone"],
        hasChild: false, // Initially, this comment has no children
        parentCommentId: PATH || null, // Null if it's a top-level comment
        score: 0,
        commentPath: "" // Initialize empty, will be updated with the actual path after adding
      };

      let commentsCollection;
      if (!PoC) {
        // If it's a child comment, add it to the comments sub-collection of the parent comment
        commentsCollection = collection(doc(db, PATH), 'comments');
      } else {
        // If it's a top-level comment, add it to the post's comments collection
        commentsCollection = collection(postDocRef, 'comments');
      }

      const commentRef = await addDoc(commentsCollection, newComment);

      const updatedCommentPath = `${PATH}/comments/${commentRef.id}`;
      await updateDoc(commentRef, { commentPath: updatedCommentPath });

      console.log("Comment added with ID:", commentRef.id);

      if (!PoC) {
        const parentCommentRef = doc(db, PATH);
        await updateDoc(parentCommentRef, {
          hasChild: true
        });
      }
    } catch (e) {
      console.error("Error adding comment:", e);
    }
  }


  load() {
    this.L = true;
  }

  isPostPathOrCommentPath(path: string): boolean {
    const trimmedPath = path.trim();
    const pathSegments = trimmedPath.split('/'); // ['posts', 'qeQO661rDtc23WarSTG']
    return pathSegments.length > 3;
  }

  async updateCommentScore(comPath: string, com:Comment, action: number) {
   if (action === 1)  com.upvotedby.push(com.username) ; 
   if (action === -1) com.downvotedby.push(com.username);
   if (action === 0) {
    com.upvotedby = com.upvotedby.filter(username => username !== com.username);
    com.downvotedby = com.downvotedby.filter(username => username !== com.username);
  }
  const S = com.upvotedby.length - com.downvotedby.length;
    const db = this.firestore;
    try {
      const postDocRef = doc(db, comPath);
      await updateDoc(postDocRef, { score: S, upvotedby: com.upvotedby, downvotedby: com.downvotedby  });
    } catch (e) {
      console.error("Error updating comment score: ", e);
      return null;
    }
    return;
  }

  getParentPath(commentPath: string): string | null {
    const pathParts = commentPath.split('/comments/');
    if (pathParts.length > 1) {
      return pathParts.slice(0, -1).join('/comments/');
    }
    return null; // This is a root-level comment
  }

/*
  async getPostsByUser(userId: string) {
    const db = this.firestore;
    const postsCollection = collection(db, "posts");

    try {
      const q = query(postsCollection, where("poster_id", "==", userId));
      const querySnapshot = await getDocs(q);

      const userPosts = [];

      for (const docSnap of querySnapshot.docs) {
        const postData = docSnap.data();
        const postId = docSnap.id;

        const postDocRef = doc(db, `posts/${postId}`);
        const commentsCollection = collection(postDocRef, 'comments');
        const commentsSnapshot = await getDocs(commentsCollection);

        const postWithComments = {
          id: postId,
          ...postData,
          comments: await Promise.all(commentsSnapshot.docs.map(async (commentDoc) => {
            const commentData = commentDoc.data();
            const commentId = commentDoc.id;

            return {
              id: commentId,
              ...commentData,
            };
          }))
        };

        userPosts.push(postWithComments);
      }

      console.log("Posts by user with comments:", userPosts);
      return userPosts;
    } catch (e) {
      console.error("Error fetching posts by user:", e);
    }
  } */
}
