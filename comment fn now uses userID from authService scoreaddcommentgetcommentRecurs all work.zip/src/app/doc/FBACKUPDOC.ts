import { Component } from '@angular/core';
import { collection, addDoc,getDocs } from "firebase/firestore"; 
import { Inject } from '@angular/core';
import { Firestore } from '@angular/fire/firestore';
import { doc,setDoc,updateDoc,getDoc } from '@angular/fire/firestore';
import {  query, where } from '@angular/fire/firestore';

@Component({
  selector: 'app-doc',
  standalone: true,
  template: `
  <button type="submit" (click)="updateCommentScore('/posts/xip6QZ4V05vHW3RTzCrg/comments/qHlqqt3SktFPq8MYqQAj/comments/5D2nBr1coBsNDdzT8mLM/comments/OD6qCxOv5Jyfx72JZZ2b/comments/I91bXuDkLbUo3CjxarSd' )">
    Add Comment
  </button>
`, //addComment('yYCneuz8ZzChWw1GsYiV', 'based', 'username' )
  //"getPostsByUser('USer_1' )"
  

  // templateUrl: './doc.component.html',
  styleUrls: ['./doc.component.css']
})
export class DocComponent {
  constructor(@Inject(Firestore) private firestore: Firestore) {}

  async addComment(postId: string, content: string, username: string, comPath: string | null = null) {
    const db = this.firestore;
  
    try {
      const postDocRef = doc(db, `posts/${postId}`);
  
      // Verify that the post exists
      const postDocSnapshot = await getDoc(postDocRef);
      if (!postDocSnapshot.exists()) {
        console.error(`Post with ID ${postId} does not exist!`);
        return; 
      }
      console.log(`Post with ID ${postId} exists!`);
  
      const newComment = {
        content: content,
        username: username,
        date: new Date(),
        upvotedby: ["yassin", "radi"],
        downvotedby: ["sam", "james", "someone"],
        hasChild: false, // initially, this comment has no children
        parentCommentId: comPath || null, // null if it's a top-level comment
        score: 0,
        commentPath: "" // Initialize empty, will be updated with the actual path after adding
      };
  
      // Determine the correct collection for the comment
      let commentsCollection;
      if (comPath) {
        // If it's a child comment, add it to the comments sub-collection of the parent comment
        commentsCollection = collection(doc(db, comPath), 'comments');
      } else {
        // If it's a top-level comment, add it to the post's comments collection
        commentsCollection = collection(postDocRef, 'comments');
      }
  
      // Add the new comment to the chosen collection
      const commentRef = await addDoc(commentsCollection, newComment);
  
      // Define the comment's full path and update the comment document with this path
      const updatedCommentPath = comPath 
        ? `${comPath}/comments/${commentRef.id}` 
        : `posts/${postId}/comments/${commentRef.id}`;
      await updateDoc(commentRef, { commentPath: updatedCommentPath });
  
      console.log("Comment added with ID:", commentRef.id);
  
      // If this is a child comment, mark the parent comment as having children
      if (comPath) {
        const parentCommentRef = doc(db, comPath);
        await updateDoc(parentCommentRef, {
          hasChild: true
        });
      }
  
    } catch (e) {
      console.error("Error adding comment:", e);
    }
  }
  

  async updateCommentScore(  comPath: string ) {
    const db = this.firestore;
    
    try {
      const postDocRef = doc(db, comPath);
      await updateDoc(postDocRef, { score: 9999 }); 
    } catch (e) {
      console.error("Error updating comment score: ", e);
      return null; 
    }
    return; 
  }
  async GetComment(postId: string,  comPath: string | null = null ) {
    const db = this.firestore;
  
    try {
      const postDocRef = doc(db, `posts/${postId}`);
  
       // const postDocSnapshot = await getDoc(postDocRef);
      
     const commentsCollection = comPath ? collection(db, comPath):collection(db, 'posts/'+postId+'/comments');
      
     const commentsSnapshot = await getDocs(commentsCollection);
     const comments = commentsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
     console.log(comments);

     return comments; // Return the array of comments
 
  
    } catch (e) {
      console.error("Error adding comment: ", e);
    }
    return;
  }

/*
  async addComment(postId: string, content: string, username: string, comPath: string | null = null) {
    const db = this.firestore;
  
    try {
      // Reference to the post document
      const postDocRef = doc(db, `posts/${postId}`);
    
      // Debugging step: Check if the post or parent comment exists in Firestore
      const postDocSnapshot = await getDoc(postDocRef);
      
      if (!postDocSnapshot.exists()) {
        console.error(`Post with ID ${postId} does not exist!`);
        return; // Exit early if post doesn't exist
      }
      console.log(`Post with ID ${postId} exists!`);
  
      // Prepare the new comment object
      const newComment = {
        content: content,
        username: username,
        date: new Date(),
        upvotedby: ["yassin","radi"],
        downvotedby: ["sam","james","someone"],
        hasChild: comPath ? true : false,
        parentCommentId: comPath, // null if it's a top-level comment
        score: 0,
        commentPath: `posts/${postId}` // Initialize commentPath
      };
  
      // Get the correct comments collection reference:
      // If it's a child comment, use the comments sub-collection under the parent comment
      // If it's a top-level comment, use the comments collection under the post
      let commentsCollection;
      if (comPath) {
        // If it's a child comment, reference the comments sub-collection of the parent comment
        commentsCollection = collection(doc(db, comPath), 'comments');
      } else {
        // If it's a top-level comment, reference the comments collection of the post
        commentsCollection = collection(postDocRef, 'comments');
      }
  
      // Add the new comment document to the appropriate comments sub-collection
      const commentRef = await addDoc(commentsCollection, newComment);
  
      // After adding the comment, update the `commentPath` to include the comment ID
      const updatedCommentPath =comPath ? `${comPath}/comments/${commentRef.id}`: `posts/${postId}/comments/${commentRef.id}`;

     // const updatedCommentPath = `${comPath}/${commentRef.id}`;
      await updateDoc(commentRef, { commentPath: updatedCommentPath });
  
      console.log("Comment added with ID: ", commentRef.id);
  
      // If this is a child comment, update the parent comment's `commentPath`
      if (comPath) {
        // Use the correct path to the parent comment where you want to add the child comment reference
        const parentCommentRef = doc(db, comPath);
        await updateDoc(parentCommentRef, {
          commentPath: updatedCommentPath // Update the parent's path to include the child comment
        });
      }
  
    } catch (e) {
      console.error("Error adding comment: ", e);
    }
  } */


  /*
  async  fetchComments(post_id: string, comPath: string | null = null): Promise<any[]> {
  const db = this.firestore;
  const rootCommentRef = doc(db, `posts/${post_id}`);
  const subCommentRef= comPath ? doc(db, comPath) : rootCommentRef;
  const commentsCollection = comPath ?  collection(rootCommentRef, 'comments'):collection(subCommentRef, 'comments');
  const commentsSnapshot = await getDocs(commentsCollection);
  const comments = [];

  for (const commentDoc of commentsSnapshot.docs) {
    const commentData = commentDoc.data();
    const commentId = commentDoc.id;

    // Create a comment object 
    // const commentWithSubComments = {
    //   id: commentId,
    //   ...commentData,
    //  subComments: await fetchComments(db, doc(db, `posts/${commentData.commentPath}/comments/${commentId}`)) // Recursively fetch sub-comments
   // };

    comments.push(commentData);
  }
console.log(comments)
  return comments;
  
}*/

// Function to recursively fetch comments and their sub-comments
async fetchComments(post_id: string, comPath: string | null = null): Promise<any[]> {
  const db = this.firestore;

  // Reference to the root post or a specific comment
  const rootCommentRef = doc(db, `posts/${post_id}`);
  const targetCommentRef = comPath ? doc(db, comPath) : rootCommentRef;

  // Get the comments sub-collection based on whether it's a post or a specific comment
  const commentsCollection = collection(targetCommentRef, 'comments');
  const commentsSnapshot = await getDocs(commentsCollection);

  const comments = [];

  // Loop through the comments and process each one
  for (const commentDoc of commentsSnapshot.docs) {
    const commentData = commentDoc.data();
    const commentId = commentDoc.id;

    // Construct the commentPath for this comment
    const commentPath = comPath ? `${comPath}/comments/${commentId}` : `posts/${post_id}/comments/${commentId}`;

    // Fetch sub-comments recursively by passing the current commentPath
    const subComments = await this.fetchComments(post_id, commentPath);

    // Create a comment object that includes sub-comments
    const commentWithSubComments = {
      id: commentId,
      ...commentData,
      subComments: subComments, // Recursively fetched sub-comments
    };

    // Add the comment to the list
    comments.push(commentWithSubComments);
  }

  console.log(comments); // Log the final list of comments with sub-comments
  return comments;
}


// Function to get posts by user with nested comments
async  getPostsByUser(userId: string) {
  const db = this.firestore;
  const postsCollection = collection(db, "posts");

  try {
    // Query the 'posts' collection for documents where 'poster_id' is equal to the specified userId
    const q = query(postsCollection, where("poster_id", "==", userId));
    const querySnapshot = await getDocs(q);

    const userPosts = [];

    // Fetch posts and their comments (including sub-comments)
    for (const docSnap of querySnapshot.docs) {
      const postData = docSnap.data();
      const postId = docSnap.id;

      // Get a reference to the post document
      const postDocRef = doc(db, `posts/${postId}`);
      
      // Get comments sub-collection reference for the post
      const commentsCollection = collection(postDocRef, 'comments');
      const commentsSnapshot = await getDocs(commentsCollection);
      
      // Attach comments (with sub-comments) to the post data
      const postWithComments = {
        id: postId,
        ...postData,
        comments: await Promise.all(commentsSnapshot.docs.map(async (commentDoc) => {
          const commentData = commentDoc.data();
          const commentId = commentDoc.id;

          // Create the comment object with its sub-comments recursively
          return {
            id: commentId,
            ...commentData,
        //    subComments: await fetchComments(db, doc(db, `posts/${postId}/comments/${commentId}`)) // Recursively fetch sub-comments
          };
        }))
      };

      // Add post with comments and sub-comments to result array
      userPosts.push(postWithComments);
    }

    console.log("Posts by user with comments and sub-comments:", userPosts);
    return userPosts;
  } catch (e) {
    console.error("Error fetching posts for user:", e);
    return [];
  }
}

  
  
  


  async addPost() {//this code can create a post and leave a place holder for comments
    const db = this.firestore;

    try {
      const docRef = await addDoc(collection(db, "posts"), {
        post_content: "Ada wong is the best",
        poster_id: "USer_1",
        date: 1815,
        score:0,
      });
      console.log("Document written with ID: ", docRef.id);
            // Create an empty 'comments' sub-collection by adding a placeholder document
    const commentsRef = doc(db, `posts/${docRef.id}/comments/placeholder`);
    await setDoc(commentsRef, { placeholder: true });
    console.log("Empty comments collection created for post ID:", docRef.id);

    } catch (e) {
      console.error("Error adding document: ", e);
    }
  }

/*
  async getPostsByUser(userId: string) {
    const db = this.firestore;
    const postsCollection = collection(db, "posts");
  
    try {
      // Query the 'posts' collection for documents where 'poster_id' is equal to the specified userId
      const q = query(postsCollection, where("poster_id", "==", userId));
      const querySnapshot = await getDocs(q);
  
      // Extract and return the data from each document in the query results
      const userPosts = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      console.log("Posts by user:", userPosts);
  
      return userPosts;
    } catch (e) {
      console.error("Error fetching posts for user:", e);
      return [];
    }
  } */
 
  



/*
      async addComment(postId: string, content: string, username: string, parentCommentId: string | null = null) {
        const db = this.firestore;
      
        try {
          // Generate a unique document reference within `posts/${postId}/comments`
          const commentsCollectionPath = `posts/${postId}/comments`;
          const commentDocRef = doc(collection(db, commentsCollectionPath));
      
          // Define the new comment with a reference to its parent if applicable
          const newComment = {
            content: content,
            username: username,
            date: new Date(),
            parentCommentId: parentCommentId,
            score: 0,
            commentPath: `${commentsCollectionPath}/${commentDocRef.id}`
          };
      
          // Set the new comment document
          await setDoc(commentDocRef, newComment);
          console.log("Comment added with ID:", commentDocRef.id);
      
        } catch (e) {
          console.error("Error adding comment:", e);
        }
      } */

/*
async addComment(postId: string, content: string, username: string, parentCommentId: string | null = null) {
  const db = this.firestore;

  try {
    // Reference to the comments collection within the specified post
    const commentPath = parentCommentId 
      ? `posts/${postId}/comments/${parentCommentId}/comments`
      : `posts/${postId}/comments`;

    // Generate a new comment document with an ID in the specified path
    const commentDocRef = doc(collection(db, commentPath));

    // Comment data
    const newComment = {
      content: content,
      username: username,
      date: new Date(),
      parentCommentId: parentCommentId, 
      score: 0,
      commentPath: commentDocRef.path
    };

    // Add or update the comment document without duplicating the postId
    await setDoc(commentDocRef, newComment);
    console.log("Comment added with ID: ", commentDocRef.id);
  } catch (e) {
    console.error("Error adding comment: ", e);
  }
} */

      

    


  ngOnInit() {
  //  this.addPost();  // Calls addDocument when component initializes
   // this.querySnapshot();  // Calls addDocument when component initializes
   // this.getPostsByUser("1");
  // this.addComment('IzuiMud2gUSdUEM6aVRQ', 'content', 'username',  null );
  }


  //getting data 
  async querySnapshot() {
    const db = this.firestore;
    const querySnapshot = await getDocs(collection(db, "users"));
    querySnapshot.forEach((doc) => {
      console.log(`${doc.id} => ${doc.data()}`);
    });

  }



}