import { Component, inject } from '@angular/core';
//import { initializeApp } from '@angular/fire/app';
//import { getFirestore } from '@angular/fire/firestore';
import { collection, getDocs,Firestore } from '@angular/fire/firestore';
import { AngularFireModule } from '@angular/fire/compat';

import { Auth, User, onAuthStateChanged } from '@angular/fire/auth';


 @Component({
  selector: 'app-test',
  standalone: true,
  imports: [ AngularFireModule,],
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})




export class TestComponent {
   //app = initializeApp(firebaseConfig); //matjich t7oot il variable hadah cont app
   //ma3dech lazema app deja 3maltha fil config.ts
   //db = getFirestore(this.app);         // wila hada const db
   private db: Firestore = inject(Firestore);
   private auth: Auth = inject(Auth);  // Inject Firebase Auth to get user

   cityList!: any[]; // declare cityList as a property of the class

   userIdentifier: string | null = null; // To store user identifier (e.g., email or display name)
   userUID: string | null = null;        // To store user UID
 
   constructor() {
    this.getCities(); // Call getCities() when the component is initialized
    this.getCurrentUser(); // Call getCurrentUser() to get user information

  } // constructor force  the code to run at startup



  // Get a list of cities from your database
  async getCities() {
    const citiesCol = collection(this.db, 'cities'); // Use the injected Firestore instance
    const citySnapshot = await getDocs(citiesCol);
    this.cityList = citySnapshot.docs.map(doc => doc.data());
    this.cityList.forEach((city) => {
      console.log(city.name);
      console.log(city.country);  
      console.log(city.population); 
    })
   //  this.logCityNames();
  }

  logCityNames() {
    this.cityList.forEach((city) => {
      console.log(city.name);
    });

  
  }
  getCurrentUser() {
    onAuthStateChanged(this.auth, (user: User | null) => {
      if (user) {
        this.userIdentifier = user.email || user.displayName || "Anonymous";
        this.userUID = user.uid;
        console.log("User Identifier:", this.userIdentifier);
        console.log("User UID:", this.userUID);
      } else {
        console.log("No user is currently signed in.");
      }
    });
  }



}


// const firebaseConfig = {
//   apiKey: "AIzaSyDS9dJ_rJG4MolUKjHqa0bnaOKb6aX3q9Y",
//   authDomain: "ang-project-159fc.firebaseapp.com",
//   projectId: "ang-project-159fc",
//   storageBucket: "ang-project-159fc.firebasestorage.app",
//   messagingSenderId: "461357606678",
//   appId: "1:461357606678:web:234d99af8eee9d484f9237"
// };

  // getCities the wrong wway using firebaseConfig in comp
 /* async  getCities(db: Firestore) { // do not write  async function getCities(db){}  // *function* ma tjich lina 5ater typeScript
                  //lazem t7oot il type fil TypeScript
    const citiesCol = collection(db, 'cities');// import collection from '@angular/fire/firestore';
    const citySnapshot = await getDocs(citiesCol);//import getDocs from '@angular/fire/firestore';
    const cityList = citySnapshot.docs.map(doc => doc.data());
    return this.cityList;}
    logCityNames() {
      this.cityList.map((city) => {
        console.log(city.name);
      });} */