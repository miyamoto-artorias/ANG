import { Routes } from '@angular/router';
import { CommentComponent } from './comment/comment.component';

export const routes: Routes = [
    {path: 'app-comment', component: CommentComponent},




];
