import { Injectable } from '@angular/core';
import { Auth, signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup, createUserWithEmailAndPassword, onAuthStateChanged, User as FirebaseUser, signOut } from '@angular/fire/auth';
import { Router } from '@angular/router';

export interface User {
  email: string | null;
  photoURL: string | null;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService { 
  private user: User = { email: null, photoURL: null };

  constructor(private auth: Auth, private router: Router) {
    // Restore user from localStorage if available
    if (typeof window !== 'undefined') {
      const storedUser = localStorage.getItem('user');
      if (storedUser) {
        this.user = JSON.parse(storedUser);
      }
    }

    // Listen for auth state changes
    onAuthStateChanged(this.auth, (firebaseUser) => {
      if (firebaseUser) {
        this.setUser({
          email: firebaseUser.email,
          photoURL: firebaseUser.photoURL,
        });
   //     this.router.navigate(['/mainpage']);
      } else {
        this.clearUser();
      }
    });
  }

  // Manage user state
  setUser(user: User) {
    this.user = user;
    if (typeof window !== 'undefined') {
      localStorage.setItem('user', JSON.stringify(user));
    }
  }

  clearUser() {
    this.user = { email: null, photoURL: null };
    if (typeof window !== 'undefined') {
      localStorage.removeItem('user');
    }
  }

  getUser() {
    return this.user;
  }

  // Login with email and password
  async loginWithEmail(email: string, password: string): Promise<void> {
    try {
      const userCredential = await signInWithEmailAndPassword(this.auth, email, password);
      this.setUser({
        email: userCredential.user.email,
        photoURL: userCredential.user.photoURL,
      });
      console.log('User logged in successfully:', userCredential.user.email);
          // Route only if the current path is not already '/app-comment'
    if (this.router.url !== '/app-comment') {
      await this.router.navigate(['/app-comment']);
    }

    } catch (error) {
      throw new Error('Invalid login credentials.');
    }
  }

  // Login with Google
  async loginWithGoogle(): Promise<void> {
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const userCredential = await signInWithPopup(this.auth, provider);
      this.setUser({
        email: userCredential.user.email,
        photoURL: userCredential.user.photoURL,
      });
    //  this.router.navigate(['/mainpage']);
    } catch (error) {
      throw new Error('Failed to login with Google.');
    }
  }

  // Sign up with email and password
  async signup(email: string, password: string): Promise<void> {
    try {
      const userCredential = await createUserWithEmailAndPassword(this.auth, email, password);
      this.setUser({
        email: userCredential.user.email,
        photoURL: userCredential.user.photoURL,
      });
 //     this.router.navigate(['/mainpage']);
    } catch (error) {
      throw new Error('Error during sign-up.');
    }
  }

  // Logout
  async logout(): Promise<void> {
    try {
      await signOut(this.auth);
      this.clearUser();
  //    this.router.navigate(['/login']);
    } catch (error) {
      throw new Error('Failed to logout.');
    }
  }
}
