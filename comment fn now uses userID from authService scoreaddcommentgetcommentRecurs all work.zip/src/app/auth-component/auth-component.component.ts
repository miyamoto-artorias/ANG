import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import { CommonModule, isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-auth',
  imports: [CommonModule],
  standalone: true,
  templateUrl: './auth-component.component.html',
  styleUrls: ['./auth-component.component.css']
})
export class AuthComponent implements OnInit {
  ui: firebaseui.auth.AuthUI | undefined;

  private firebaseConfig = {
    apiKey: "AIzaSyDS9dJ_rJG4MolUKjHqa0bnaOKb6aX3q9Y",
    authDomain: "ang-project-159fc.firebaseapp.com",
    projectId: "ang-project-159fc",
    storageBucket: "ang-project-159fc.firebasestorage.app",
    messagingSenderId: "461357606678",
    appId: "1:461357606678:web:234d99af8eee9d484f9237"
  
  };
  

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {
    if (isPlatformBrowser(this.platformId)) {
      if (!firebase.apps.length) {
        firebase.initializeApp(this.firebaseConfig);
      }
    }
  }

  async ngOnInit(): Promise<void> {
    if (isPlatformBrowser(this.platformId)) {
      const firebaseui = await import('firebaseui');
      this.ui = new firebaseui.auth.AuthUI(firebase.auth());

      const uiConfig = {
        callbacks: {
          signInSuccessWithAuthResult: (authResult: any) => {
            console.log('User signed in successfully:', authResult);
            return false; // Prevents automatic redirection
          },
          uiShown: () => {
            document.getElementById('loader')!.style.display = 'none';
          }
        },
        signInFlow: 'popup',
        signInOptions: [
          // Email/Password provider for sign-in and sign-up
          {
            provider: firebase.auth.EmailAuthProvider.PROVIDER_ID,
            requireDisplayName: true  // Prompts the user to enter their name on sign-up
          },
          // Google provider
          firebase.auth.GoogleAuthProvider.PROVIDER_ID
        ],
        tosUrl: '<your-terms-of-service-url>',
        privacyPolicyUrl: '<your-privacy-policy-url>'
      };

      this.ui.start('#firebaseui-auth-container', uiConfig);
    }
  }

  ngOnDestroy(): void {
    if (this.ui) {
      this.ui.delete();
    }
  }
}




















// import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
// import firebase from 'firebase/compat/app';
// import 'firebase/compat/auth';
// import { isPlatformBrowser } from '@angular/common';

// @Component({
//   selector: 'app-auth',
//   standalone: true,
//   templateUrl: './auth-component.component.html',
//   styleUrls: ['./auth-component.component.css']
// })
// export class AuthComponent implements OnInit {
//   ui: firebaseui.auth.AuthUI | undefined;

//   private firebaseConfig = {
//     apiKey: "AIzaSyDS9dJ_rJG4MolUKjHqa0bnaOKb6aX3q9Y",
//     authDomain: "ang-project-159fc.firebaseapp.com",
//     projectId: "ang-project-159fc",
//     storageBucket: "ang-project-159fc.firebasestorage.app",
//     messagingSenderId: "461357606678",
//     appId: "1:461357606678:web:234d99af8eee9d484f9237"
//   };

//   constructor(@Inject(PLATFORM_ID) private platformId: Object) {
//     if (isPlatformBrowser(this.platformId)) {
//       // Initialize Firebase only on the client side
//       if (!firebase.apps.length) {
//         firebase.initializeApp(this.firebaseConfig);
//       }
//     }
//   }

//   async ngOnInit(): Promise<void> {
//     if (isPlatformBrowser(this.platformId)) {
//       // Dynamically import firebaseui for client-side only
//       const firebaseui = await import('firebaseui');
//       this.ui = new firebaseui.auth.AuthUI(firebase.auth());

//       const uiConfig = {
//         callbacks: {
//           signInSuccessWithAuthResult: (authResult: any) => {
//             console.log('User signed in successfully:', authResult);
//             return false; // Prevents automatic redirection
//           },
//           uiShown: () => {
//             document.getElementById('loader')!.style.display = 'none';
//           }
//         },
//         signInFlow: 'popup',
//         signInOptions: [
//           firebase.auth.GoogleAuthProvider.PROVIDER_ID,
//           firebase.auth.EmailAuthProvider.PROVIDER_ID
//         ],
//         tosUrl: '<your-terms-of-service-url>',
//         privacyPolicyUrl: '<your-privacy-policy-url>'
//       };

//       this.ui.start('#firebaseui-auth-container', uiConfig);
//     }
//   }

//   ngOnDestroy(): void {
//     if (this.ui) {
//       this.ui.delete();
//     }
//   }
// }
