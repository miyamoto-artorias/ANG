import { Component, OnInit, Input } from '@angular/core';
import { Comment } from '../doc/comment';
import { CommonModule } from '@angular/common';
import { CommentService } from './comment.service';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-comment',
  standalone: true,
  imports: [CommonModule],
  styleUrls: ['./comment.component.css'],
  templateUrl: './comment.component.html',
})
export class CommentComponent implements OnInit {
  constructor(private CommentService: CommentService,private authService: AuthService) {
    this.userid = this.authService.getUser().email ?? ''; //the ?? for in case it return null

  }
  userid:string ;
  L = false;
  comments?: Comment[];
  commentPaths: string[] = [];
  @Input() commentsInput: string = '/posts/xip6QZ4V05vHW3RTzCrg';
//  userid =  this.authService.getUser().email;
  async ngOnInit(): Promise<void> {
    if (this.commentsInput) {
      this.comments = await this.CommentService.getComments(this.commentsInput);
      if (this.comments) {
        for (const comment of this.comments) {
          if (comment.commentPath) {
            this.commentPaths.push(comment.commentPath);
          }
        }
      }
      console.log(this.commentPaths);
    }
    await console.log(this.authService.getUser().email);
  }

  addPost(): void {
    this.CommentService.addPost();
  }

  addComment(PATH: string, content: string, username: string ): void {
    this.CommentService.addComment(PATH, content, username);
  }

  updateCommentScore(comPath: string, com: Comment, action: number,userid:string): void {
    this.CommentService.updateCommentScore(comPath, com, action,userid);
  }

  load(): void {
    this.L = true;
  }
}
