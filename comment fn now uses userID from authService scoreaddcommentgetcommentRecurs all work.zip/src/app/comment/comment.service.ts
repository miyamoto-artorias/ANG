import { Injectable } from '@angular/core';
import { Firestore, collection, addDoc, getDocs, doc, setDoc, updateDoc, getDoc } from '@angular/fire/firestore';
import { Comment } from '../doc/comment';

@Injectable({
  providedIn: 'root'
})
export class CommentService {
  constructor(private firestore: Firestore) {}

  async addPost(): Promise<void> {
    const db = this.firestore;
    try {
      const docRef = await addDoc(collection(db, "posts"), {
        post_content: "Ada wong is the best",
        poster_id: "USer_1",
        date: 1815,
        score: 0,
      });
      console.log("Document written with ID: ", docRef.id);
      const commentsRef = doc(db, `posts/${docRef.id}/comments/placeholder`);
      await setDoc(commentsRef, { placeholder: true });
      console.log("Empty comments collection created for post ID:", docRef.id);
    } catch (e) {
      console.error("Error adding document: ", e);
    }
  }

  async getComments(comPath: string): Promise<Comment[]> {
    const db = this.firestore;
    try {
      const commentsCollection = collection(db, comPath + '/comments');
      const commentsSnapshot = await getDocs(commentsCollection);
      return commentsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        commentPath: doc.data()['commentPath']
      })) as Comment[];
    } catch (e) {
      console.error("Error fetching comments: ", e);
      return [];
    }
  }

  async addComment(PATH: string, content: string, username: string): Promise<void> {
    const db = this.firestore;
    try {
      const postDocRef = doc(db, PATH);
      const postDocSnapshot = await getDoc(postDocRef);

      if (!postDocSnapshot.exists()) {
        console.error(`Post with ID ${PATH} does not exist!`);
        return;
      }

      const newComment: Comment = {
        content,
        username,
        date: new Date(),
        upvotedby: [],
        downvotedby: [],
        hasChild: false,
        parentCommentId: PATH || null,
        score: 0,
        commentPath: ""
      };

      const commentsCollection = collection(postDocRef, 'comments');
      const commentRef = await addDoc(commentsCollection, newComment);

      const updatedCommentPath = `${PATH}/comments/${commentRef.id}`;
      await updateDoc(commentRef, { commentPath: updatedCommentPath });

      console.log("Comment added with ID:", commentRef.id);
    } catch (e) {
      console.error("Error adding comment:", e);
    }
  }

  // async updateCommentScore(comPath: string, com: Comment, action: number, userid:string): Promise<void> {
  //   if (action === 1) com.upvotedby.push(userid);
  //   if (action === -1) com.downvotedby.push(userid);
  //   if (action === 0) {
  //     com.upvotedby = com.upvotedby.filter(username => username !== userid);
  //     com.downvotedby = com.downvotedby.filter(username => username !== userid);
  //   }
  //   const S = com.upvotedby.length - com.downvotedby.length;

  //   const db = this.firestore;
  //   try {
  //     const postDocRef = doc(db, comPath);
  //     await updateDoc(postDocRef, { score: S, upvotedby: com.upvotedby, downvotedby: com.downvotedby });
  //   } catch (e) {
  //     console.error("Error updating comment score: ", e);
  //   }
  // }

  async updateCommentScore(comPath: string, com: Comment, action: number, userid: string): Promise<void> {
    const db = this.firestore;
  
    try {
      // Determine if the user has already upvoted or downvoted
      const hasUpvoted = com.upvotedby.includes(userid);
      const hasDownvoted = com.downvotedby.includes(userid);
  
      // Handle action
      if (action === 1) {
        if (hasDownvoted) {
          // Remove from downvoted and add to upvoted
          com.downvotedby = com.downvotedby.filter(user => user !== userid);
        }
        if (!hasUpvoted) {
          com.upvotedby.push(userid);
        } else {
          // If already upvoted, remove the user
          com.upvotedby = com.upvotedby.filter(user => user !== userid);
        }
      } else if (action === -1) {
        if (hasUpvoted) {
          // Remove from upvoted and add to downvoted
          com.upvotedby = com.upvotedby.filter(user => user !== userid);
        }
        if (!hasDownvoted) {
          com.downvotedby.push(userid);
        } else {
          // If already downvoted, remove the user
          com.downvotedby = com.downvotedby.filter(user => user !== userid);
        }
      } else if (action === 0) {
        // Neutral action: remove user from both arrays
        com.upvotedby = com.upvotedby.filter(user => user !== userid);
        com.downvotedby = com.downvotedby.filter(user => user !== userid);
      }
  
      // Calculate the new score
      const S = com.upvotedby.length - com.downvotedby.length;
  
      // Update Firestore
      const postDocRef = doc(db, comPath);
      await updateDoc(postDocRef, { score: S, upvotedby: com.upvotedby, downvotedby: com.downvotedby });
    } catch (e) {
      console.error("Error updating comment score: ", e);
    }
  }
  
}
