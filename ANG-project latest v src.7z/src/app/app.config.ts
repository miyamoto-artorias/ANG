import { ApplicationConfig, importProvidersFrom, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { provideFirebaseApp, getApp, initializeApp } from '@angular/fire/app';
import { getFirestore, provideFirestore } from '@angular/fire/firestore';
import { getAuth, provideAuth } from '@angular/fire/auth'; // Import Auth functions


import { routes } from './app.routes';
import { provideClientHydration } from '@angular/platform-browser';

const firebaseConfig = {
  apiKey: "AIzaSyDS9dJ_rJG4MolUKjHqa0bnaOKb6aX3q9Y",
  authDomain: "ang-project-159fc.firebaseapp.com",
  projectId: "ang-project-159fc",
  storageBucket: "ang-project-159fc.firebasestorage.app",
  messagingSenderId: "461357606678",
  appId: "1:461357606678:web:234d99af8eee9d484f9237"
};


export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideClientHydration(),
    provideFirebaseApp(() => initializeApp(firebaseConfig)),
    provideFirestore(() => getFirestore()),
    provideAuth(() => getAuth()) // Add Auth provider
  ],
};
// export const appConfig: ApplicationConfig = {
//   providers: [provideZoneChangeDetection({ eventCoalescing: true }), provideRouter(routes), provideClientHydration(),
//     importProvidersFrom([
//       provideFirebaseApp(() => initializeApp(firebaseConfig)),
//       provideFirestore(() => getFirestore()),
//   ])],
// };
