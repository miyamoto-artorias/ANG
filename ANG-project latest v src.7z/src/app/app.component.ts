import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { DocComponent } from "./doc/doc.component";
import { AuthComponent } from "./auth-component/auth-component.component";
import { TestComponent } from './test/test.component';
import { AngularFireModule } from '@angular/fire/compat';
import { CommentComponent } from "./comment/comment.component";
import { CommentsComponent } from './comments/comments.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, DocComponent, AuthComponent, TestComponent, AngularFireModule, CommentComponent,CommentsComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'ANG-PROJECT';
}
