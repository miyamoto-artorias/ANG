import { Component } from '@angular/core';
import { collection, addDoc,getDocs } from "firebase/firestore"; 
import { Inject } from '@angular/core';
import { Firestore } from '@angular/fire/firestore';
import { doc,setDoc,updateDoc,getDoc } from '@angular/fire/firestore';
import {  query, where } from '@angular/fire/firestore';

@Component({
  selector: 'app-doc',
  standalone: true,
  template: `
  <button type="submit" (click)="GetComments('qeQO661rDtc23WarSTG9','/posts/qeQO661rDtc23WarSTG9' )">
  Add Comment
  </button>


`, //addComment('yYCneuz8ZzChWw1GsYiV', 'based', 'username' )
  //"getPostsByUser('USer_1' )"
  

  // templateUrl: './doc.component.html',
  styleUrls: ['./doc.component.css']
})
export class DocComponent {
  constructor(@Inject(Firestore) private firestore: Firestore) {}

  async addComment(postId: string, content: string, username: string, comPath: string | null = null) {
    const db = this.firestore;
  
    try {
      const postDocRef = doc(db, `posts/${postId}`);
  
      // Verify that the post exists
      const postDocSnapshot = await getDoc(postDocRef);
      if (!postDocSnapshot.exists()) {
        console.error(`Post with ID ${postId} does not exist!`);
        return; 
      }
      console.log(`Post with ID ${postId} exists!`);
  
      const newComment = {
        content: content,
        username: username,
        date: new Date(),
        upvotedby: ["yassin", "radi"],
        downvotedby: ["sam", "james", "someone"],
        hasChild: false, // initially, this comment has no children
        parentCommentId: comPath || null, // null if it's a top-level comment
        score: 0,
        commentPath: "" // Initialize empty, will be updated with the actual path after adding
      };
  
      // Determine the correct collection for the comment
      let commentsCollection;
      if (comPath) {
        // If it's a child comment, add it to the comments sub-collection of the parent comment
        commentsCollection = collection(doc(db, comPath), 'comments');
      } else {
        // If it's a top-level comment, add it to the post's comments collection
        commentsCollection = collection(postDocRef, 'comments');
      }
  
      // Add the new comment to the chosen collection
      const commentRef = await addDoc(commentsCollection, newComment);
  
      // Define the comment's full path and update the comment document with this path
      const updatedCommentPath = comPath 
        ? `${comPath}/comments/${commentRef.id}` 
        : `posts/${postId}/comments/${commentRef.id}`;
      await updateDoc(commentRef, { commentPath: updatedCommentPath });
  
      console.log("Comment added with ID:", commentRef.id);
  
      // If this is a child comment, mark the parent comment as having children
      if (comPath) {
        const parentCommentRef = doc(db, comPath);
        await updateDoc(parentCommentRef, {
          hasChild: true
        });
      }
  
    } catch (e) {
      console.error("Error adding comment:", e);
    }
  }
  

  async updateCommentScore(  comPath: string ) {
    const db = this.firestore;
    
    try {
      const postDocRef = doc(db, comPath);
      await updateDoc(postDocRef, { score: 9999 }); 
    } catch (e) {
      console.error("Error updating comment score: ", e);
      return null; 
    }
    return; 
  }


    async GetComments(postId: string,  comPath: string | null = null ) {
      const db = this.firestore;
    
      try {
        const postDocRef = doc(db, `posts/${postId}`);
    
         // const postDocSnapshot = await getDoc(postDocRef);
        
       const commentsCollection = comPath ? collection(db, comPath+'/comments'):collection(db, 'posts/'+postId+'/comments');
        
       const commentsSnapshot = await getDocs(commentsCollection);
       const comments = commentsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
       console.log(comments);
  
       return comments; // Return the array of comments
   
    
      } catch (e) {
        console.error("Error adding comment: ", e);
      }
      return;
    }





// Function to recursively fetch comments and their sub-comments
async fetchComments(post_id: string, comPath: string | null = null): Promise<any[]> {
  const db = this.firestore;

  // Reference to the root post or a specific comment
  const rootCommentRef = doc(db, `posts/${post_id}`);
  const targetCommentRef = comPath ? doc(db, comPath) : rootCommentRef;

  // Get the comments sub-collection based on whether it's a post or a specific comment
  const commentsCollection = collection(targetCommentRef, 'comments');
  const commentsSnapshot = await getDocs(commentsCollection);

  const comments = [];

  // Loop through the comments and process each one
  for (const commentDoc of commentsSnapshot.docs) {
    const commentData = commentDoc.data();
    const commentId = commentDoc.id;

    // Construct the commentPath for this comment
    const commentPath = comPath ? `${comPath}/comments/${commentId}` : `posts/${post_id}/comments/${commentId}`;

    // Fetch sub-comments recursively by passing the current commentPath
    const subComments = await this.fetchComments(post_id, commentPath);

    // Create a comment object that includes sub-comments
    const commentWithSubComments = {
      id: commentId,
      ...commentData,
      subComments: subComments, // Recursively fetched sub-comments
    };

    // Add the comment to the list
    comments.push(commentWithSubComments);
  }

  console.log(comments); // Log the final list of comments with sub-comments
  return comments;
}


// Function to get posts by user with nested comments
async  getPostsByUser(userId: string) {
  const db = this.firestore;
  const postsCollection = collection(db, "posts");

  try {
    // Query the 'posts' collection for documents where 'poster_id' is equal to the specified userId
    const q = query(postsCollection, where("poster_id", "==", userId));
    const querySnapshot = await getDocs(q);

    const userPosts = [];

    // Fetch posts and their comments (including sub-comments)
    for (const docSnap of querySnapshot.docs) {
      const postData = docSnap.data();
      const postId = docSnap.id;

      // Get a reference to the post document
      const postDocRef = doc(db, `posts/${postId}`);
      
      // Get comments sub-collection reference for the post
      const commentsCollection = collection(postDocRef, 'comments');
      const commentsSnapshot = await getDocs(commentsCollection);
      
      // Attach comments (with sub-comments) to the post data
      const postWithComments = {
        id: postId,
        ...postData,
        comments: await Promise.all(commentsSnapshot.docs.map(async (commentDoc) => {
          const commentData = commentDoc.data();
          const commentId = commentDoc.id;

          // Create the comment object with its sub-comments recursively
          return {
            id: commentId,
            ...commentData,
        //    subComments: await fetchComments(db, doc(db, `posts/${postId}/comments/${commentId}`)) // Recursively fetch sub-comments
          };
        }))
      };

      // Add post with comments and sub-comments to result array
      userPosts.push(postWithComments);
    }

    console.log("Posts by user with comments and sub-comments:", userPosts);
    return userPosts;
  } catch (e) {
    console.error("Error fetching posts for user:", e);
    return [];
  }
}

  
  
  


  async addPost() {//this code can create a post and leave a place holder for comments
    const db = this.firestore;

    try {
      const docRef = await addDoc(collection(db, "posts"), {
        post_content: "Ada wong is the best",
        poster_id: "USer_1",
        date: 1815,
        score:0,
      });
      console.log("Document written with ID: ", docRef.id);
            // Create an empty 'comments' sub-collection by adding a placeholder document
    const commentsRef = doc(db, `posts/${docRef.id}/comments/placeholder`);
    await setDoc(commentsRef, { placeholder: true });
    console.log("Empty comments collection created for post ID:", docRef.id);

    } catch (e) {
      console.error("Error adding document: ", e);
    }
  }

/*
  async getPostsByUser(userId: string) {
    const db = this.firestore;
    const postsCollection = collection(db, "posts");
  
    try {
      // Query the 'posts' collection for documents where 'poster_id' is equal to the specified userId
      const q = query(postsCollection, where("poster_id", "==", userId));
      const querySnapshot = await getDocs(q);
  
      // Extract and return the data from each document in the query results
      const userPosts = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      console.log("Posts by user:", userPosts);
  
      return userPosts;
    } catch (e) {
      console.error("Error fetching posts for user:", e);
      return [];
    }
  } */
 
  




      

    


  ngOnInit() {
  //  this.addPost();  // Calls addDocument when component initializes
   // this.querySnapshot();  // Calls addDocument when component initializes
   // this.getPostsByUser("1");
  // this.addComment('IzuiMud2gUSdUEM6aVRQ', 'content', 'username',  null );
  }


  //getting data // mochklethat it doesn't get all the nested data so it's kinda useless for know
  async querySnapshot() {
    const db = this.firestore;
    const querySnapshot = await getDocs(collection(db, "users"));
    querySnapshot.forEach((doc) => {
      console.log(`${doc.id} => ${doc.data()}`);
    });

  }



}