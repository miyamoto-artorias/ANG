import { Component } from '@angular/core';
import { collection, addDoc,getDocs } from "firebase/firestore"; 
import { Inject } from '@angular/core';
import { Firestore } from '@angular/fire/firestore';
import { doc,setDoc,updateDoc,getDoc } from '@angular/fire/firestore';
import {  query, where } from '@angular/fire/firestore';

@Component({
  selector: 'app-doc',
  standalone: true,
  template: `
  <button type="submit" (click)="getPostsByUser('USer_1' )">
    Add Comment
  </button>
`, //addComment('yYCneuz8ZzChWw1GsYiV', 'based', 'username' )


  // templateUrl: './doc.component.html',
  styleUrls: ['./doc.component.css']
})
export class DocComponsdfgsdfgsdfgsdgvent {
  constructor(@Inject(Firestore) private firestore: Firestore) {}


  async addComment(postId: string, content: string, username: string, comPath: string | null = null) {
    const db = this.firestore;
  
    try {
      const postDocRef = doc(db, `posts/${postId}`);
  
    //  const targetDocRef = comPath ? doc(db, comPath) : postDocRef;
  
      const postDocSnapshot = await getDoc(postDocRef);
      
      if (!postDocSnapshot.exists()) {
        console.error(`Post with ID ${postId} does not exist!`);
        return; 
      } console.log(`Post with ID ${postId} exists!`);
     
  
      const newComment = {
        content: content,
        username: username,
        date: new Date(),
        upvotedby: ["yassin","radi"],
        downvotedby: ["sam","james","someone"],
        hasChild: comPath ? true : false,
        parentCommentId: comPath, // null if it's a top-level comment
        score: 0,
        commentPath: `posts/${postId}` // Initialize commentPath
      };
  
      let commentsCollection;
      if (comPath) {
        // If it's a child comment, reference the comments sub-collection of the parent comment
        commentsCollection = collection(doc(db, comPath), 'comments');
      } else {
        // If it's a top-level comment, reference the comments collection of the post
        commentsCollection = collection(postDocRef, 'comments');
      }
  
      // Add the new comment document to the appropriate comments sub-collection
      const commentRef = await addDoc(commentsCollection, newComment);
  
      // After adding the comment, update the `commentPath` to include the comment ID
      const updatedCommentPath =comPath ? `${comPath}/comments/${commentRef.id}`: `posts/${postId}/comments/${commentRef.id}`;

     // const updatedCommentPath = `${comPath}/${commentRef.id}`;
      await updateDoc(commentRef, { commentPath: updatedCommentPath });
  
      console.log("Comment added with ID: ", commentRef.id);
  
      // If this is a child comment, update the parent comment's `commentPath`
      if (comPath) {
        // Use the correct path to the parent comment where you want to add the child comment reference
        const parentCommentRef = doc(db, comPath);
        await updateDoc(parentCommentRef, {
          commentPath: updatedCommentPath // Update the parent's path to include the child comment
        });
      }
  
    } catch (e) {
      console.error("Error adding comment: ", e);
    }
  }
  async GetComment(postId: string, content: string, username: string, comPath: string ) {
    const db = this.firestore;
  
    try {
      // Reference to the post document
      const postDocRef = doc(db, `posts/${postId}`);
  
  
      // Debugging step: Check if the post or parent comment exists in Firestore
      const postDocSnapshot = await getDoc(postDocRef);
      
      if (!postDocSnapshot.exists()) {
        console.error(`Post with ID ${postId} does not exist!`);
        return; // Exit early if post doesn't exist
      }
     // const commentsCollection = collection(postDocRef, comPath);

      const commentsCollection = collection(db, comPath);

  
      console.log(commentsCollection);
  
    } catch (e) {
      console.error("Error adding comment: ", e);
    }
  }
  // Function to recursively fetch comments and their sub-comments
async  fetchComments(db: any, commentRef: any): Promise<any[]> {
  const commentsCollection = collection(commentRef, 'comments');
  const commentsSnapshot = await getDocs(commentsCollection);
  
  const comments = [];

  for (const commentDoc of commentsSnapshot.docs) {
    const commentData = commentDoc.data();
    const commentId = commentDoc.id;

    // Create a comment object
    const commentWithSubComments = {
      id: commentId,
      ...commentData,
    //  subComments: await fetchComments(db, doc(db, `posts/${commentData.commentPath}/comments/${commentId}`)) // Recursively fetch sub-comments
    };

    comments.push(commentWithSubComments);
  }

  return comments;
}

// Function to get posts by user with nested comments
async  getPostsByUser(userId: string) {
  const db = this.firestore;
  const postsCollection = collection(db, "posts");

  try {
    // Query the 'posts' collection for documents where 'poster_id' is equal to the specified userId
    const q = query(postsCollection, where("poster_id", "==", userId));
    const querySnapshot = await getDocs(q);

    const userPosts = [];

    // Fetch posts and their comments (including sub-comments)
    for (const docSnap of querySnapshot.docs) {
      const postData = docSnap.data();
      const postId = docSnap.id;

      // Get a reference to the post document
      const postDocRef = doc(db, `posts/${postId}`);
      
      // Get comments sub-collection reference for the post
      const commentsCollection = collection(postDocRef, 'comments');
      const commentsSnapshot = await getDocs(commentsCollection);
      
      // Attach comments (with sub-comments) to the post data
      const postWithComments = {
        id: postId,
        ...postData,
        comments: await Promise.all(commentsSnapshot.docs.map(async (commentDoc) => {
          const commentData = commentDoc.data();
          const commentId = commentDoc.id;

          // Create the comment object with its sub-comments recursively
          return {
            id: commentId,
            ...commentData,
        //    subComments: await fetchComments(db, doc(db, `posts/${postId}/comments/${commentId}`)) // Recursively fetch sub-comments
          };
        }))
      };

      // Add post with comments and sub-comments to result array
      userPosts.push(postWithComments);
    }

    console.log("Posts by user with comments and sub-comments:", userPosts);
    return userPosts;
  } catch (e) {
    console.error("Error fetching posts for user:", e);
    return [];
  }
}

  
  
  


  async addPost() {//this code can create a post and leave a place holder for comments
    const db = this.firestore;

    try {
      const docRef = await addDoc(collection(db, "posts"), {
        post_content: "Ada wong is the best",
        poster_id: "USer_1",
        date: 1815,
        score:0,
      });
      console.log("Document written with ID: ", docRef.id);
            // Create an empty 'comments' sub-collection by adding a placeholder document
    const commentsRef = doc(db, `posts/${docRef.id}/comments/placeholder`);
    await setDoc(commentsRef, { placeholder: true });
    console.log("Empty comments collection created for post ID:", docRef.id);

    } catch (e) {
      console.error("Error adding document: ", e);
    }
  }

 
  



  //getting data 
  async querySnapshot() {
    const db = this.firestore;
    const querySnapshot = await getDocs(collection(db, "users"));
    querySnapshot.forEach((doc) => {
      console.log(`${doc.id} => ${doc.data()}`);
    });

  }



}