import { Component, Input, OnInit } from '@angular/core';
import { Firestore, collection, addDoc, getDocs, query, where, orderBy, updateDoc, doc } from '@angular/fire/firestore';
import { Auth } from '@angular/fire/auth';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { from } from 'rxjs'; // for loadComment()
import{FormsModule,NgForm} from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-comment',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css'],
})
export class CommentComponent implements OnInit {
  @Input() postId!: string; // The ID of the post this comment belongs to
  @Input() parentCommentId: string | null = null; // ID of the parent comment (null if it's a top-level comment)

  comments$: Observable<any[]> | undefined;
  userId: string | null = null; // To store logged-in user ID
  content: string = ''; // Content of a new comment

  constructor(private firestore: Firestore, private auth: Auth) {}

  ngOnInit(): void {
    this.auth.onAuthStateChanged(user => {
      if (user) {
        this.userId = user.uid;
      } else {
        console.error('User not authenticated');
      }
    });
    this.loadComments();
  }

  // Load comments for the current post and parentCommentId
  // loadComments() {
  //   const commentsRef = collection(this.firestore, 'comments');
  //   const commentsQuery = query(
  //     commentsRef,
  //     where('postId', '==', this.postId),
  //     where('parentCommentId', '==', this.parentCommentId),
  //     orderBy('date', 'asc')
  //   );
  //   this.comments$ = getDocs(commentsQuery).then(snapshot => 
  //     snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
  //   );
  // }

  
  // loadComments() {
  //   const commentsRef = collection(this.firestore, 'comments');
  //   const commentsQuery = query(
  //     commentsRef,
  //     where('postId', '==', this.postId),
  //     where('parentCommentId', '==', this.parentCommentId),
  //     orderBy('date', 'asc')
  //   );
  //   this.comments$ = from(getDocs(commentsQuery)).pipe(
  //     map(snapshot => snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })))
  //   );
  // }
  async loadComments() {
    try {
      const commentsRef = collection(this.firestore, 'comments');
      const commentsQuery = query(
        commentsRef,
        where('postId', '==', this.postId),
        where('parentCommentId', '==', this.parentCommentId),
        orderBy('date', 'asc')
      );
      const commentSnapshot = await getDocs(commentsQuery);
           this.comments$ = from(getDocs(commentsQuery)).pipe(
       map(snapshot => snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })))
     );
    } catch (error) {
      console.error('Error loading comments: ', error);
    }
  }

  // // Add a new comment
  // async addComment() {
  //   if (!this.userId) {
  //     console.error('User not authenticated.');
  //     return;
  //   }
  //   const newComment = {
  //     postId: this.postId,
  //     userId: this.userId,
  //     date: new Date(),
  //     score: 0,
  //     content: this.content,
  //     parentCommentId: this.parentCommentId,
  //   };
  //   await addDoc(collection(this.firestore, 'comments'), newComment);
  //   this.content = ''; // Clear the input
  //   this.loadComments(); // Reload comments to show the new one
  // }
  async addComment() {
    if (!this.userId) {
      console.error('User not authenticated.');
      return;
    }
    
    if (!this.content.trim()) {
      console.error('Comment content cannot be empty.');
      return;
    }

    const newComment = {
      postId: this.postId,
      userId: this.userId,
      date: new Date(),
      score: 0,
      content: this.content,
      parentCommentId: this.parentCommentId || null,
    };

    try {
      const commentRef = await addDoc(collection(this.firestore, 'comments'), newComment);
      console.log('Comment added with ID: ', commentRef.id);
      this.content = '';  // Clear the input field
      this.loadComments(); // Reload comments to show the new one
    } catch (error) {
      console.error('Error adding comment: ', error);
    }
  }


  // Upvote a comment
  async upvoteComment(commentId: string, currentScore: number) {
    const commentRef = doc(this.firestore, `comments/${commentId}`);
    await updateDoc(commentRef, { score: currentScore + 1 });
    this.loadComments(); // Reload comments to update scores
  }
  

  // Downvote a comment
  async downvoteComment(commentId: string, currentScore: number) {
    const commentRef = doc(this.firestore, `comments/${commentId}`);
    await updateDoc(commentRef, { score: currentScore - 1 });
    this.loadComments(); // Reload comments to update scores
  }
}
