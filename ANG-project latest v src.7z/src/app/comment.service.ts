import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Observable } from 'rxjs';

export interface Comment {
  id?: string;
  postId: string;
  parentId?: string; // For recursive comments
  username: string;
  userType: string;
  date: Date;
  content: string;
  score: number;
  replies?: Comment[];
}


@Injectable({
  providedIn: 'root',
})
export class CommentService {
  constructor(private firestore: AngularFirestore) {}

  // Add a comment
  addComment(postId: string, comment: any) {
    return this.firestore.collection(`posts/${postId}/comments`).add(comment);
  }

  // Fetch comments by post ID with recursive structure
  getComments(postId: string): Observable<any[]> {
    return this.firestore
      .collection(`posts/${postId}/comments`, (ref) =>
        ref.orderBy('date', 'asc')
      )
      .valueChanges({ idField: 'id' }); 
  }

  // Update comment score
 
}
